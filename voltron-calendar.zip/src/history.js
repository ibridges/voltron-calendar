
import fs from "fs";
import path from "path";
const dir=path.join(process.cwd(),"calendar-data");
const file=path.join(dir,"history.json");
const norm=s=>JSON.stringify({regular:s.regular,season:s.season});
export function loadHistory(){
 if(!fs.existsSync(dir)) fs.mkdirSync(dir,{recursive:true});
 if(!fs.existsSync(file)) return {version:1,snapshots:[]};
 try{return JSON.parse(fs.readFileSync(file,"utf8"));}catch{return {version:1,snapshots:[]};}
}
export function saveSnapshot(snapshot){
 const h=loadHistory();
 const last=h.snapshots.at(-1);
 if(last && norm(last)===norm(snapshot)){console.log("No changes.");return false;}
 h.snapshots.push(snapshot);
 fs.writeFileSync(file,JSON.stringify(h,null,2));
 return true;
}
