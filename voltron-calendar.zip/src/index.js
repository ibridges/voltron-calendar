
import { scrapeCalendar } from "./scraper.js";
import { saveSnapshot } from "./history.js";
try{
 const snapshot=await scrapeCalendar();
 const saved=saveSnapshot(snapshot);
 console.log(saved?"Snapshot saved.":"No changes detected.");
 process.exit(0);
}catch(e){
 console.error(e);
 process.exit(1);
}
